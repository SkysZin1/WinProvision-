﻿param([switch]$Worker,[string]$JobPath,[switch]$Preview,[switch]$ValidateUi,[switch]$Configure,[string]$SelectionPath,[ValidateSet("","pt-BR","en-US")][string]$UiLanguage="")
$ErrorActionPreference='Stop'
$initialPlan=@{Mode='AfterBoot';Ids=@()}
if(-not $UiLanguage){$UiLanguage=if($initialPlan.InterfaceLanguage){$initialPlan.InterfaceLanguage}elseif([Globalization.CultureInfo]::CurrentUICulture.Name -like 'pt*'){'pt-BR'}else{'en-US'}}
. (Join-Path $PSScriptRoot 'Localization.ps1')
if($Configure){$Preview=$true}
if($ValidateUi){$Preview=$true}
if($Worker -and $Preview){throw (T 'Preview cannot run an installation worker.')}
$catalog=@(
 [pscustomobject]@{Id='Google.Chrome';Name='Google Chrome';Category='Browsers';Description='Browse the web and sync with your Google account.'},
 [pscustomobject]@{Id='Mozilla.Firefox';Name='Mozilla Firefox';Category='Browsers';Description='A browser with built-in tracking protection.'},
 [pscustomobject]@{Id='Brave.Brave';Name='Brave';Category='Browsers';Description='A browser with built-in ad blocking.'},
 [pscustomobject]@{Id='7zip.7zip';Name='7-Zip';Category='Utilities';Description='Open and compress ZIP, 7z and other archive formats.'},
 [pscustomobject]@{Id='VideoLAN.VLC';Name='VLC media player';Category='Media';Description='Play videos and music in a wide range of formats.'},
 [pscustomobject]@{Id='Spotify.Spotify';Name='Spotify';Category='Media';Description='Music and podcasts. Account required; paid plans available.'},
 [pscustomobject]@{Id='Discord.Discord';Name='Discord';Category='Communication';Description='Text, voice and video chat. Account required.'},
 [pscustomobject]@{Id='Valve.Steam';Name='Steam';Category='Gaming';Description='Game store and library. Account required; games sold separately.'},
 [pscustomobject]@{Id='TheDocumentFoundation.LibreOffice';Name='LibreOffice';Category='Productivity';Description='Create documents, spreadsheets and presentations.'},
 [pscustomobject]@{Id='Microsoft.VisualStudioCode';Name='Visual Studio Code';Category='Development';Description='A code editor with support for extensions.'},
 [pscustomobject]@{Id='Notepad++.Notepad++';Name='Notepad++';Category='Development';Description='A lightweight text and code editor.'},
 [pscustomobject]@{Id='Git.Git';Name='Git';Category='Development';Description='Version control for your projects.'}
)
# BEGIN ADDITIONAL APPS
$catalog+= (ConvertFrom-Json @'
[
    {
        "Id":  "GitHub.GitHubDesktop",
        "Name":  "GitHub Desktop",
        "Category":  "Development",
        "Description":  "Visual Git workflow for repositories and GitHub accounts.",
        "IconKey":  "github",
        "Color":  "#6E40C9",
        "Source":  "winget"
    },
    {
        "Id":  "RARLab.WinRAR",
        "Name":  "WinRAR",
        "Category":  "Utilities",
        "Description":  "RAR and ZIP archiver. Trial software; a license is required after evaluation.",
        "IconKey":  "archive",
        "Color":  "#8055A8",
        "Source":  "winget"
    },
    {
        "Id":  "9NKSQGP7F2NH",
        "Name":  "WhatsApp",
        "Category":  "Communication",
        "Description":  "Official Microsoft Store app. Requires a WhatsApp account and phone linking.",
        "IconKey":  "whatsapp",
        "Color":  "#168C48",
        "Source":  "msstore"
    },
    {
        "Id":  "EpicGames.EpicGamesLauncher",
        "Name":  "Epic Games Store",
        "Category":  "Gaming",
        "Description":  "Official game launcher and store. Account required; games are separate.",
        "IconKey":  "epicgames",
        "Color":  "#263238",
        "Source":  "winget"
    },
    {
        "Id":  "Python.Python.3.14",
        "Name":  "Python 3.14",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "Python interpreter and pip. Third-party libraries are installed separately.",
        "IconKey":  "python",
        "Color":  "#3776AB",
        "Source":  "winget"
    },
    {
        "Id":  "9NT1R1C2HH7J",
        "Name":  "ChatGPT",
        "Category":  "AI assistants",
        "Description":  "Official OpenAI app from Microsoft Store. Account required; plan features vary.",
        "IconKey":  "openai",
        "Color":  "#168A71",
        "Source":  "msstore"
    },
    {
        "Id":  "Anthropic.Claude",
        "Name":  "Claude",
        "Category":  "AI assistants",
        "Description":  "Official Claude desktop app. Account required; plan features vary.",
        "IconKey":  "anthropic",
        "Color":  "#B76E50",
        "Source":  "winget"
    },
    {
        "Id":  "RamenSoftware.Windhawk",
        "Name":  "Windhawk",
        "Category":  "Customization",
        "Description":  "Windows customization platform. Mods are chosen separately; compatibility varies by Windows build.",
        "IconKey":  "settings",
        "Color":  "#317BB5",
        "Source":  "winget"
    },
    {
        "Id":  "NVIDIA.App.Official",
        "Name":  "NVIDIA app",
        "Category":  "Drivers",
        "Description":  "For supported NVIDIA GPUs. Official installer may ask for input. Driver updates are configured separately.",
        "IconKey":  "nvidia",
        "Color":  "#5A8F00",
        "Source":  "nvidia",
        "Url":  "https://us.download.nvidia.com/nvapp/client/11.0.9.251/NVIDIA_app_v11.0.9.251.exe"
    },
    {
        "Id":  "Intel.IntelDriverAndSupportAssistant",
        "Name":  "Intel Driver \u0026 Support Assistant",
        "Category":  "Drivers",
        "Description":  "Detects supported Intel hardware and offers driver updates. Review updates in the tool after installation.",
        "IconKey":  "intel",
        "Color":  "#0071C5",
        "Source":  "winget"
    },
    {
        "Id":  "OpenJS.NodeJS.LTS",
        "Name":  "Node.js LTS",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "JavaScript runtime and npm for web tools and backend development.",
        "IconKey":  "nodedotjs",
        "Color":  "#43853D",
        "Source":  "winget"
    },
    {
        "Id":  "Microsoft.DotNet.SDK.10",
        "Name":  ".NET SDK 10",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "Build C#, F# and .NET applications. OS support follows the selected SDK release.",
        "IconKey":  "dotnet",
        "Color":  "#512BD4",
        "Source":  "winget"
    },
    {
        "Id":  "EclipseAdoptium.Temurin.21.JDK",
        "Name":  "Java JDK 21 (Temurin)",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "Long-term support Java development kit. Includes compiler and runtime.",
        "IconKey":  "openjdk",
        "Color":  "#B85B18",
        "Source":  "winget"
    },
    {
        "Id":  "GoLang.Go",
        "Name":  "Go",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "Go compiler and tools for backend and command-line development.",
        "IconKey":  "go",
        "Color":  "#008DAE",
        "Source":  "winget"
    },
    {
        "Id":  "Rustlang.Rustup",
        "Name":  "Rust (rustup)",
        "Category":  "Languages \u0026 SDKs",
        "Description":  "Rust toolchain manager. Native Windows builds may also require Visual Studio C++ Build Tools.",
        "IconKey":  "rust",
        "Color":  "#9B4D24",
        "Source":  "winget"
    },
    {
        "Id":  "Kitware.CMake",
        "Name":  "CMake",
        "Category":  "Development",
        "Description":  "Build configuration tools for C/C++ projects. Does not include a compiler.",
        "IconKey":  "cmake",
        "Color":  "#2879A8",
        "Source":  "winget"
    },
    {
        "Id":  "Postman.Postman",
        "Name":  "Postman",
        "Category":  "Development",
        "Description":  "Develop and test APIs. Some workflows require an account or paid plan.",
        "IconKey":  "postman",
        "Color":  "#D9562E",
        "Source":  "winget"
    },
    {
        "Id":  "Microsoft.WindowsTerminal",
        "Name":  "Windows Terminal",
        "Category":  "Development",
        "Description":  "Tabbed terminal for PowerShell and command shells. Requires a supported Windows build.",
        "IconKey":  "windowsterminal",
        "Color":  "#344A53",
        "Source":  "winget"
    },
    {
        "Id":  "Opera.OperaGX",
        "Name":  "Opera GX",
        "Category":  "Browsers",
        "Description":  "Browser with gaming features and resource controls.",
        "IconKey":  "browser-gaming",
        "Color":  "#E32955",
        "Source":  "winget"
    },
    {
        "Id":  "Zoom.Zoom",
        "Name":  "Zoom",
        "Category":  "Communication",
        "Description":  "Video meetings and team communication. Some features require an account or paid plan.",
        "IconKey":  "video-call",
        "Color":  "#2764E7",
        "Source":  "winget"
    },
    {
        "Id":  "qBittorrent.qBittorrent",
        "Name":  "qBittorrent",
        "Category":  "Utilities",
        "Description":  "Open-source BitTorrent client for downloading and sharing files.",
        "IconKey":  "downloads",
        "Color":  "#377DB5",
        "Source":  "winget"
    },
    {
        "Id":  "BlenderFoundation.Blender",
        "Name":  "Blender",
        "Category":  "Design \u0026 3D",
        "Description":  "Create 3D models, animations and renders. Hardware requirements depend on the installed version.",
        "IconKey":  "modeling",
        "Color":  "#D97620",
        "Source":  "winget"
    },
    {
        "Id":  "AntibodySoftware.WizTree",
        "Name":  "WizTree",
        "Category":  "Utilities",
        "Description":  "Analyze disk usage and find large files and folders. Review the publisher\u0027s license for your type of use.",
        "IconKey":  "disk-map",
        "Color":  "#548F31",
        "Source":  "winget"
    },
    {
        "Id":  "Anysphere.Cursor",
        "Name":  "Cursor",
        "Category":  "Development",
        "Description":  "Code editor with AI features. Some features require an account or paid plan.",
        "IconKey":  "code-cursor",
        "Color":  "#34404A",
        "Source":  "winget"
    }
]
'@)
# END ADDITIONAL APPS
function Save-Json($value,[string]$path) {
 $temp=$path+'.tmp'
 [IO.File]::WriteAllText($temp,($value | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($true))
 Move-Item -LiteralPath $temp -Destination $path -Force
}
function Get-WingetPath {
 $path=Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe'
 if(Test-Path -LiteralPath $path) { return $path }
 return $null
}
if($Worker) {
 $workerLock=[Threading.Mutex]::new($false,'Local\WinProvisionAppWorker')
 $locked=$false
 $state=$null
 try {
  try { $locked=$workerLock.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked=$true }
  if(-not $locked) { throw (T 'An installation is already running. Please wait for it to finish.') }
  $request=Get-Content -LiteralPath (Join-Path $JobPath 'request.json') -Raw | ConvertFrom-Json
  $ids=@($request.Ids | Select-Object -Unique)
  if($ids.Count -eq 0 -or @($ids | Where-Object { $_ -notin $catalog.Id }).Count) { throw (T 'Invalid app selection.') }
  $state=[pscustomobject]@{Done=$false;Message=(T 'Preparing the app installer…');Items=@($ids | ForEach-Object { [pscustomobject]@{Id=$_;Status='Queued';Code=$null} })}
  Save-Json $state (Join-Path $JobPath 'status.json')
  $state.Message=(T 'Checking internet access and App Installer…')
  Save-Json $state (Join-Path $JobPath 'status.json')
  try {
   $connection=Invoke-WebRequest -Uri 'https://www.msftconnecttest.com/connecttest.txt' -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
   if($connection.StatusCode -ne 200 -or $connection.Content.Trim() -ne 'Microsoft Connect Test'){throw 'Unexpected connectivity response.'}
  } catch { throw (T 'Internet access could not be verified. Connect to Wi-Fi or Ethernet, complete any network sign-in, then retry. No apps were installed.') }
  $winget=Get-WingetPath
  $needsWinget=@($catalog | Where-Object { $_.Id -in $ids -and $_.Source -ne 'nvidia' }).Count -gt 0
  if(-not $winget -and $needsWinget) {
   try { Add-AppxPackage -RegisterByFamilyName -MainPackage Microsoft.DesktopAppInstaller_8wekyb3d8bbwe -ErrorAction Stop } catch { $_ | Out-String | Set-Content -LiteralPath (Join-Path $JobPath 'prepare.log') }
   for($i=0;$i -lt 30 -and -not $winget;$i++) { Start-Sleep -Seconds 2; $winget=Get-WingetPath }
  }
  if(-not $winget -and $needsWinget) { throw (T 'App Installer is not available yet. Connect to the internet, install or update App Installer in Microsoft Store, then try again.') }
  if($needsWinget){
   try {
    $probe=Start-Process -FilePath $winget -ArgumentList '--version' -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $JobPath 'winget-version.log') -RedirectStandardError (Join-Path $JobPath 'winget-version.error.log')
    try {
     if(-not $probe.WaitForExit(15000)){ $probe.Kill(); throw 'App Installer timed out.' }
     if($probe.ExitCode -ne 0){throw 'App Installer failed.'}
    } finally { $probe.Dispose() }
   } catch { throw (T 'App Installer is not responding correctly. Open Microsoft Store, install or update App Installer, then retry. No apps were installed.') }
  }
  foreach($item in $state.Items) {
   if(Test-Path -LiteralPath (Join-Path $JobPath 'stop')) { $item.Status='Deferred'; continue }
   $item.Status='Installing'
   $state.Message=TF 'Installing {0}…' @(($catalog | Where-Object Id -eq $item.Id).Name)
   Save-Json $state (Join-Path $JobPath 'status.json')
   try {
    $app=$catalog | Where-Object Id -eq $item.Id
    if($app.Source -eq 'nvidia'){
     $installer=Join-Path $JobPath 'NVIDIA-app.exe'
     Invoke-WebRequest -Uri $app.Url -OutFile $installer -UseBasicParsing -ErrorAction Stop
     $signature=Get-AuthenticodeSignature -LiteralPath $installer
     if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch '(^|,\s*)CN=NVIDIA Corporation(,|$)'){throw (T 'The NVIDIA installer signature could not be verified. Installation stopped.')}
     $state.Message=(T 'NVIDIA app: complete the official installer if prompted.')
     Save-Json $state (Join-Path $JobPath 'status.json')
     $process=Start-Process -FilePath $installer -Verb RunAs -WindowStyle Normal -PassThru -Wait
    } else {
     $source=if($app.Source -eq 'msstore'){'msstore'}else{'winget'}
     $arguments=@('install','--id',$item.Id,'--exact','--source',$source,'--silent','--accept-package-agreements','--accept-source-agreements','--disable-interactivity','--no-upgrade')
     $process=Start-Process -FilePath $winget -ArgumentList $arguments -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput (Join-Path $JobPath ($item.Id+'.log')) -RedirectStandardError (Join-Path $JobPath ($item.Id+'.error.log'))
    }
    $item.Code=$process.ExitCode
    $item.Status=if($process.ExitCode -eq 0 -or $process.ExitCode -eq [int]0x8A150061){'Completed'}else{'Failed'}
   } catch {
    $item.Status='Failed'
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $JobPath ($item.Id+'.error.log'))
   }
   Save-Json $state (Join-Path $JobPath 'status.json')
  }
  $state.Done=$true
  $failed=@($state.Items | Where-Object Status -eq 'Failed').Count
  $state.Message=if($failed){(TF 'Finished with {0} failure(s). Check the logs and try again.' @($failed))}elseif(@($state.Items | Where-Object Status -eq 'Deferred').Count){(T 'Queue stopped. You can install the remaining apps later.')}else{(T 'All done! The selected apps were processed successfully.')}
  Save-Json $state (Join-Path $JobPath 'status.json')
 } catch {
  $failure=if($state){$state}else{[pscustomobject]@{Done=$true;Message='';Items=@()}}
  $failure.Done=$true;$failure.Message=$_.Exception.Message
  foreach($item in $failure.Items){if($item.Status -in @('Queued','Installing')){$item.Status='Failed'}}
  Save-Json $failure (Join-Path $JobPath 'status.json')
 } finally { if($locked){$workerLock.ReleaseMutex()}; $workerLock.Dispose() }
 exit
}
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
# BEGIN BUNDLED APP ICONS
$iconDefinitions=ConvertFrom-Json @'
{
    "Google.Chrome":  {
                          "Path":  "M12 0C8.21 0 4.831 1.757 2.632 4.501l3.953 6.848A5.454 5.454 0 0 1 12 6.545h10.691A12 12 0 0 0 12 0zM1.931 5.47A11.943 11.943 0 0 0 0 12c0 6.012 4.42 10.991 10.189 11.864l3.953-6.847a5.45 5.45 0 0 1-6.865-2.29zm13.342 2.166a5.446 5.446 0 0 1 1.45 7.09l.002.001h-.002l-5.344 9.257c.206.01.413.016.621.016 6.627 0 12-5.373 12-12 0-1.54-.29-3.011-.818-4.364zM12 16.364a4.364 4.364 0 1 1 0-8.728 4.364 4.364 0 0 1 0 8.728Z",
                          "Color":  "#4285F4"
                      },
    "Mozilla.Firefox":  {
                            "Path":  "M8.824 7.287c.008 0 .004 0 0 0zm-2.8-1.4c.006 0 .003 0 0 0zm16.754 2.161c-.505-1.215-1.53-2.528-2.333-2.943.654 1.283 1.033 2.57 1.177 3.53l.002.02c-1.314-3.278-3.544-4.6-5.366-7.477-.091-.147-.184-.292-.273-.446a3.545 3.545 0 01-.13-.24 2.118 2.118 0 01-.172-.46.03.03 0 00-.027-.03.038.038 0 00-.021 0l-.006.001a.037.037 0 00-.01.005L15.624 0c-2.585 1.515-3.657 4.168-3.932 5.856a6.197 6.197 0 00-2.305.587.297.297 0 00-.147.37c.057.162.24.24.396.17a5.622 5.622 0 012.008-.523l.067-.005a5.847 5.847 0 011.957.222l.095.03a5.816 5.816 0 01.616.228c.08.036.16.073.238.112l.107.055a5.835 5.835 0 01.368.211 5.953 5.953 0 012.034 2.104c-.62-.437-1.733-.868-2.803-.681 4.183 2.09 3.06 9.292-2.737 9.02a5.164 5.164 0 01-1.513-.292 4.42 4.42 0 01-.538-.232c-1.42-.735-2.593-2.121-2.74-3.806 0 0 .537-2 3.845-2 .357 0 1.38-.998 1.398-1.287-.005-.095-2.029-.9-2.817-1.677-.422-.416-.622-.616-.8-.767a3.47 3.47 0 00-.301-.227 5.388 5.388 0 01-.032-2.842c-1.195.544-2.124 1.403-2.8 2.163h-.006c-.46-.584-.428-2.51-.402-2.913-.006-.025-.343.176-.389.206-.406.29-.787.616-1.136.974-.397.403-.76.839-1.085 1.303a9.816 9.816 0 00-1.562 3.52c-.003.013-.11.487-.19 1.073-.013.09-.026.181-.037.272a7.8 7.8 0 00-.069.667l-.002.034-.023.387-.001.06C.386 18.795 5.593 24 12.016 24c5.752 0 10.527-4.176 11.463-9.661.02-.149.035-.298.052-.448.232-1.994-.025-4.09-.753-5.844z",
                            "Color":  "#FF7139"
                        },
    "Brave.Brave":  {
                        "Path":  "M15.68 0l2.096 2.38s1.84-.512 2.709.358c.868.87 1.584 1.638 1.584 1.638l-.562 1.381.715 2.047s-2.104 7.98-2.35 8.955c-.486 1.919-.818 2.66-2.198 3.633-1.38.972-3.884 2.66-4.293 2.916-.409.256-.92.692-1.38.692-.46 0-.97-.436-1.38-.692a185.796 185.796 0 01-4.293-2.916c-1.38-.973-1.712-1.714-2.197-3.633-.247-.975-2.351-8.955-2.351-8.955l.715-2.047-.562-1.381s.716-.768 1.585-1.638c.868-.87 2.708-.358 2.708-.358L8.321 0h7.36zm-3.679 14.936c-.14 0-1.038.317-1.758.69-.72.373-1.242.637-1.409.742-.167.104-.065.301.087.409.152.107 2.194 1.69 2.393 1.866.198.175.489.464.687.464.198 0 .49-.29.688-.464.198-.175 2.24-1.759 2.392-1.866.152-.108.254-.305.087-.41-.167-.104-.689-.368-1.41-.741-.72-.373-1.617-.69-1.757-.69zm0-11.278s-.409.001-1.022.206-1.278.46-1.584.46c-.307 0-2.581-.434-2.581-.434S4.119 7.152 4.119 7.849c0 .697.339.881.68 1.243l2.02 2.149c.192.203.59.511.356 1.066-.235.555-.58 1.26-.196 1.977.384.716 1.042 1.194 1.464 1.115.421-.08 1.412-.598 1.776-.834.364-.237 1.518-1.19 1.518-1.554 0-.365-1.193-1.02-1.413-1.168-.22-.15-1.226-.725-1.247-.95-.02-.227-.012-.293.284-.851.297-.559.831-1.304.742-1.8-.089-.495-.95-.753-1.565-.986-.615-.232-1.799-.671-1.947-.74-.148-.068-.11-.133.339-.175.448-.043 1.719-.212 2.292-.052.573.16 1.552.403 1.632.532.079.13.149.134.067.579-.081.445-.5 2.581-.541 2.96-.04.38-.12.63.288.724.409.094 1.097.256 1.333.256s.924-.162 1.333-.256c.408-.093.329-.344.288-.723-.04-.38-.46-2.516-.541-2.961-.082-.445-.012-.45.067-.579.08-.129 1.059-.372 1.632-.532.573-.16 1.845.009 2.292.052.449.042.487.107.339.175-.148.069-1.332.508-1.947.74-.615.233-1.476.49-1.565.986-.09.496.445 1.241.742 1.8.297.558.304.624.284.85-.02.226-1.026.802-1.247.95-.22.15-1.413.804-1.413 1.169 0 .364 1.154 1.317 1.518 1.554.364.236 1.355.755 1.776.834.422.079 1.08-.4 1.464-1.115.384-.716.039-1.422-.195-1.977-.235-.555.163-.863.355-1.066l2.02-2.149c.341-.362.68-.546.68-1.243 0-.697-2.695-3.96-2.695-3.96s-2.274.436-2.58.436c-.307 0-.972-.256-1.585-.461-.613-.205-1.022-.206-1.022-.206z",
                        "Color":  "#FB542B"
                    },
    "7zip.7zip":  {
                      "Path":  "M0 18.858h24V8.181H10.717V5.142H0ZM2.021 7.271h6.657v1.994c-1.74 2.09-2.84 4.502-2.948 7.404H3.477c.09-2.501.353-4.954 2.283-6.994l.033-.033H2.021Zm8.45 1.253h13.215v10.143H10.47Zm6.01 1.213v6.871h1.482v-6.87Zm2.755.043v6.912h1.616v-2.42h1.029c.43-.001.754-.29.969-.716.427-.848.429-2.257-.024-3.092-.227-.419-.571-.697-1.033-.684zm-7.924.002v1.596h2.217l-2.304 3.736v1.54h4.287V15.1h-2.698l2.786-3.909v-1.41Zm9.452 1.512h.595c.164-.006.287.081.371.217.17.273.172.736.004.99a.364.364 0 0 1-.373.176l-.55.047z",
                      "Color":  "#252A31"
                  },
    "VideoLAN.VLC":  {
                         "Path":  "M12.0319 0c-.8823 0-1.0545.136-1.0545.136-.1738.056-.3556.255-.4105.43L9.683 3.3808c.4729.1729 1.3222.4266 2.2337.4266 1.0987 0 2.017-.3494 2.3763-.5075L13.4352.566c-.055-.1755-.237-.3707-.4067-.4374 0 0-.1142-.1286-.9966-.1286zm3.5645 7.455c-.3601.34-1.3276.9373-3.6797.9373-2.2929 0-3.189-.5678-3.5213-.9113l-1.3887 4.4227c.2272.3614 1.2539 1.5594 4.8847 1.5594 3.7569 0 4.8539-1.3467 5.0649-1.6737zm-8.5897 4.4487l-1.0025 3.1922H4.3428c-.2486 0-.5097.1932-.5826.4315l-2.334 7.6317a.3962.3962 0 0 0-.0169.1537c-.0008.0053-.002.0099-.002.016 0 .0839.0233.226.0233.226.0322.2456.2612.4452.5098.4452h20.1192c.2487 0 .4768-.1994.5098-.4453 0 0 .0234-.142.0234-.226a.0245.0245 0 0 0-.0025-.01.3201.3201 0 0 0 .0024-.0313.4096.4096 0 0 0-.019-.1282l-2.3339-7.6318c-.0729-.2383-.334-.4314-.5826-.4314h-1.6636l.2005.6391c-.2407.4854-1.4886 2.38-6.3027 2.38-4.6003 0-5.8288-1.73-6.1107-2.3072z",
                         "Color":  "#E87500"
                     },
    "Spotify.Spotify":  {
                            "Path":  "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z",
                            "Color":  "#16883D"
                        },
    "Discord.Discord":  {
                            "Path":  "M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z",
                            "Color":  "#5865F2"
                        },
    "Valve.Steam":  {
                        "Path":  "M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.605 0 11.979 0zM7.54 18.21l-1.473-.61c.262.543.714.999 1.314 1.25 1.297.539 2.793-.076 3.332-1.375.263-.63.264-1.319.005-1.949s-.75-1.121-1.377-1.383c-.624-.26-1.29-.249-1.878-.03l1.523.63c.956.4 1.409 1.5 1.009 2.455-.397.957-1.497 1.41-2.454 1.012H7.54zm11.415-9.303c0-1.662-1.353-3.015-3.015-3.015-1.665 0-3.015 1.353-3.015 3.015 0 1.665 1.35 3.015 3.015 3.015 1.663 0 3.015-1.35 3.015-3.015zm-5.273-.005c0-1.252 1.013-2.266 2.265-2.266 1.249 0 2.266 1.014 2.266 2.266 0 1.251-1.017 2.265-2.266 2.265-1.253 0-2.265-1.014-2.265-2.265z",
                        "Color":  "#18364F"
                    },
    "TheDocumentFoundation.LibreOffice":  {
                                              "Path":  "M16.365 0a.597.597 0 00-.555.352.582.582 0 00.128.635l4.985 4.996a.605.605 0 00.635.133.59.59 0 00.363-.53V.577A.605.605 0 0021.335 0zM2.661 0a.59.59 0 00-.582.59v22.82a.59.59 0 00.582.59h18.67a.59.59 0 00.59-.59V8.716a.59.59 0 00-.17-.42L13.674.182a.59.59 0 00-.42-.181zm.59 1.184h9.754l7.733 7.77v13.863H3.251z",
                                              "Color":  "#168A2F"
                                          },
    "Microsoft.VisualStudioCode":  {
                                       "Path":  "M23.15 2.587L18.21.21a1.494 1.494 0 0 0-1.705.29l-9.46 8.63-4.12-3.128a.999.999 0 0 0-1.276.057L.327 7.261A1 1 0 0 0 .326 8.74L3.899 12 .326 15.26a1 1 0 0 0 .001 1.479L1.65 17.94a.999.999 0 0 0 1.276.057l4.12-3.128 9.46 8.63a1.492 1.492 0 0 0 1.704.29l4.942-2.377A1.5 1.5 0 0 0 24 20.06V3.939a1.5 1.5 0 0 0-.85-1.352zm-5.146 14.861L10.826 12l7.178-5.448v10.896z",
                                       "Color":  "#007ACC"
                                   },
    "Notepad++.Notepad++":  {
                                "Path":  "M14.443 2.285c-.305.005-.6.06-.853.248-.256.168-.546.32-.723.578a6.273 6.273 0 00-.71 2.463c-1.009-.413-2.08-.716-3.177-.676a8.602 8.602 0 00-1.93.604c-1.26.657-2.058 1.943-2.53 3.246a6.84 6.84 0 00-.604 1.805c-.107.568-.322 1.115-.357 1.695-.002.394.029.788.023 1.182-.422.263-.926.245-1.398.328-.34-.008-.67-.18-1.014-.07-.36.172-.75.269-1.111.437-.087.51-.166 1.225.457 1.424 1.064-.002 2.132.002 3.195.021.192.98.38 1.99.898 2.86.613.987 1.213 2.025 2.147 2.75.888.593 2.02.617 3.039.441.387-.043.656-.35 1.004-.492.212-.126.527-.156.607-.428.698-1.13.163-2.531-.47-3.56-.403-.707-1.275-.853-2.018-.82-.436.065-.712.44-1.063.667-.388.235-.761.735-.468 1.186.251.473.561 1.107 1.193 1.074.399-.046.932-.136 1.106-.553.077-.505-.519-.748-.92-.838.019.247.045.494.07.743-.207-.143-.415-.28-.625-.418.128-.667.87-.65 1.38-.854.52.81 1.068 1.852.645 2.815-.489.612-1.37.535-2.054.375-.894-.137-1.487-.933-1.881-1.682-.594-1.035-1.323-2.145-1.196-3.387.417-.021.834-.02 1.25.004.398.094.752.438 1.182.27.922-.252 1.881-.1 2.822-.11.74-.052 1.484-.062 2.225-.031.268.073.411.4.72.38.358.12.558-.246.827-.4a17.954 17.954 0 011.79.002c.283.494.706 1.022 1.31 1.092.734.027 1.356-.493 1.753-1.064.52.117 1.082.282 1.586.021 1.095-.464 2.3-.464 3.43-.785v-.322c-.907-.61-2.027-.441-3.043-.695-.775-.133-1.562-.012-2.34-.022-.345-.236-.683-.509-1.119-.537-.134.059-.27.113-.404.168.356.04.728.12.994.38-.336-.02-.684-.004-1.002-.126-.428.157-.835.4-.902.894-.182-.255.083-.493.189-.72-.24-.507-.826-.768-.994-1.315a.289.289 0 01.48-.008c.234.345.426.715.573 1.104.217.013.435.027.654.045v-.25c-.109.045-.216.09-.322.142-.189-.412-.351-.837-.485-1.271.258.062.506.155.766.207 1.176-.184 2.439-.412 3.36-1.232.194-.2.542-.37.484-.698-.057-.474-.402-.841-.573-1.277.267-.101.535-.2.793-.32.918-.899 1.377-2.185 1.477-3.448-.092-.673-.282-1.413-.803-1.886-.95-.48-2.07-.324-3.035.025-.437.174-.76.527-1.123.813-.296-.066-.477-.41-.672-.633-.375-.64-.89-1.235-1.596-1.51-.293-.011-.608-.055-.914-.05zm.395.516c.59.02 1.109.506 1.443.972.222.37.524.682.885.916a5.218 5.218 0 01-.277 3.791c-.167.375-.519.605-.864.795-.91.267-1.874-.133-2.521-.783l.012-.094c-.458-.214-.537-.767-.616-1.21-.39-.893-.293-1.916-.006-2.823.212-.71.756-1.39 1.526-1.498a1.12 1.12 0 01.418-.066zm5.592 1.025c.616.002 1.29.28 1.44.926.48 1.112-.052 2.344-.688 3.273-.368.345-.792.627-1.137 1-.425-.844-1.359-1.219-2.223-1.437.16-.808.04-1.628.022-2.44.468-.835 1.44-1.154 2.326-1.304.084-.011.172-.018.26-.018zm.775 1.62a7.73 7.73 0 01-.523.138c-.125.181-.252.363-.381.545.141.372.636.718.984.38a1.297 1.297 0 00-.08-1.064c-.178-.318 0 0 0 0zm-11.988.046c.9-.011 1.793.272 2.601.653.38.153.353.6.438.933.065.26.14.516.217.774.126.383.292.78.62 1.037.546.418 1.108.867 1.794 1.025a2.425 2.425 0 001.787-.303c.45-.404.668-1.007 1.137-1.396.44.215.927.318 1.351.568.44.278.653.777.912 1.207.09.194.164.392.242.588-.786.782-1.936.988-2.974 1.23-.43.128-.829-.096-1.186-.304-.184.101-.367.209-.552.309a3.718 3.718 0 01-2.145.45 32.773 32.773 0 01-.55-.072c.084-.376.182-.749.259-1.127-.092.008-.277.02-.37.026-.31.476-.325 1.052-.263 1.597.015.207.028.413.037.62a1.573 1.573 0 01-.408-.932c.016-.391.065-.778.1-1.168-.41-.177-.571.292-.647.596 0 .168.012.335.024.502-.714.163-1.48.246-2.188.011-.514-.168-1.075-.182-1.557-.445-.016-.2-.033-.398-.054-.596-.141-.026-.282-.051-.422-.08-.189.507-.452 1.021-.424 1.575.095.365.401.634.629.925-.335.098-.791.022-1.016.334-.135.601.413.948.772 1.319-.516-.19-1.089-.463-1.266-1.03.26-.302.554-.57.881-.797-.471-.698-.676-1.743-.066-2.421-.118-.143-.257-.39-.477-.268-.172.162-.318.35-.484.52-.7.533-.976 1.386-1.399 2.12-.205-.007-.41-.013-.615-.013l-.01-.254a4.621 4.621 0 01-.023-1.014c.153-.596.418-1.158.568-1.755l.051-.194.086-.293c.452-1.231 1.008-2.494 2.012-3.379.642-.636 1.563-.81 2.396-1.07.06-.003.122-.007.182-.008zm5.12.496c-.38-.012-.738.145-.675.596-.055.394.323.572.592.76.602-.003.872-.686.707-1.178a1.264 1.264 0 00-.623-.178zm-8.064 5.79a1.865 1.865 0 00.225 1.622c-.391.203-.826.213-1.256.211-.09-.648.318-1.202.621-1.736.137-.03.275-.062.41-.098zm1.213.544c.353.101.773.09 1.051.358-.042.174-.083.348-.113.525a5.16 5.16 0 00-.654.465 1.747 1.747 0 01-.284-1.348zm7.168.324c.211.023.262.279.4.407.236.306.573.512.852.775-.67.018-1.475.102-1.88-.562-.271.074-.543.183-.684.445l-.4-.217c-.005-.25.004-.502.025-.752h.457c.412.003.824-.028 1.23-.096zm-5.306.147c.02.336.18.73-.07 1.02-.246-.021-.492-.041-.733-.084.326-.195.567-.505.674-.87zm2.51.117c.315.24.445.634.591.986-.938.036-1.878.023-2.814-.039.064-.31.17-.61.252-.916.655-.02 1.313 0 1.97-.03zm.826.535c.152.184.318.355.498.512.24-.277.775-.727.998-.193-.363.174-.813.305-.934.742l-.012.053c.076.381.178.756.307 1.123-.773-.505-.391-1.548-.857-2.237zm-10.815.293c-.02.295-.422.42-.373.727.091.29.21.57.354.838-.491-.023-.989.003-1.475-.088-.046-.256-.161-.635.11-.805.259-.16.47-.389.615-.658.255.04.516.036.77-.014zm.66.153c-.208.362-.461.81-.138 1.191l-.176.078a2.664 2.664 0 01-.361-.676c.102-.184.195-.374.28-.566.132-.006.263-.015.395-.027zm.518.086l.033.08.11-.047c-.04.227-.205.391-.346.562.233.014.296.764-.041.557a10.992 10.992 0 01-.127-.225c.024-.227-.012-.48.181-.648l.055-.067.086-.095.049-.117zm3.943.074c.347.082.895-.121 1.11.166.31.05.603.197.92.205 1.122-.329 2.316-.154 3.47-.154.006.1.02.298.028.398-.869.033-1.737.036-2.604.014-.452-.003-.881-.307-1.338-.17-.2.018-.424.229-.6.043-.28-.003-.562-.012-.843-.018-.045-.17-.1-.34-.143-.484zm-2.428.017c.375.05.849-.096 1.131.225l-.12.27c-.74-.036-1.48-.043-2.221-.065.151-.495.8-.404 1.21-.43zm15.87.016c.502-.022.98.166 1.478.215.003.207.065.428-.035.623-.608.116-1.185.383-1.81.398.011-.168.02-.336.023-.506l.287-.187.057-.543zm-1.61.014c.102 0 .205.004.307.01.229.044.396.227.588.347-.552.275-1.181.207-1.772.127-.456-.062-.93.022-1.377-.115l.125-.225c.708-.06 1.416-.151 2.13-.144zm-3.761.097c.217.002.434.006.652.006.022.22-.071.326-.28.319-.517.014-1.034.012-1.55-.018-.05-.306.34-.249.525-.295.217-.013.435-.014.653-.012zm-.516.647c.542 0 1.083.051 1.615.152.744-.097 1.494-.005 2.235-.135.306.024.95-.115.876.371-.349.042-.674-.177-1.027-.14-.694.043-1.393.107-2.08-.045-.787.165-1.591.088-2.387.137a17.27 17.27 0 00-.021-.305c.268-.03.546-.024.789-.035zm-10.418.012c.6 0 1.203.111 1.803.132l.125.143c-.808-.002-1.622.062-2.426-.022a13.543 13.543 0 01-.104-.209c.2-.032.402-.044.602-.044zm3.426.119c.34.003.683.008 1.025.002 1.337.016 2.672.035 4.006.125a6.16 6.16 0 00-.098.168c-1.304.043-2.606.02-3.91.015l-.822-.029c-.067-.094-.134-.19-.201-.281zm8.642.39c.43.192.857.393 1.305.543.259-.104.615-.671.826-.26-.328.305-.791.614-1.26.51-.36-.17-.59-.52-.87-.793zm-11.984.07l.33.05c.363.841.38 1.81.873 2.599.284.467.518.96.793 1.432.287.492.762.824 1.207 1.162.955.702 2.52.596 3.197-.438.427-.922-.104-1.898-.474-2.74-.634-.996-2.29-.238-2.242.848.364.218.767.663 1.222.384a10.497 10.497 0 01-.013-.533c.108.12.19.261.296.383-.255.329-.67.314-1.045.262-.151-.168-.307-.331-.46-.496-.188-1.083 1.193-1.994 2.11-1.446.655.42.838 1.228 1.099 1.91.301.821-.144 1.793-.924 2.159-.601.388-1.346.234-2.018.234-.917-.044-1.515-.793-2.117-1.387-.58-.712-.958-1.557-1.41-2.351a7.712 7.712 0 01-.424-2.031z",
                                "Color":  "#44792C"
                            },
    "Git.Git":  {
                    "Path":  "M23.546 10.93L13.067.452c-.604-.603-1.582-.603-2.188 0L8.708 2.627l2.76 2.76c.645-.215 1.379-.07 1.889.441.516.515.658 1.258.438 1.9l2.658 2.66c.645-.223 1.387-.078 1.9.435.721.72.721 1.884 0 2.604-.719.719-1.881.719-2.6 0-.539-.541-.674-1.337-.404-1.996L12.86 8.955v6.525c.176.086.342.203.488.348.713.721.713 1.883 0 2.6-.719.721-1.889.721-2.609 0-.719-.719-.719-1.879 0-2.598.182-.18.387-.316.605-.406V8.835c-.217-.091-.424-.222-.6-.401-.545-.545-.676-1.342-.396-2.009L7.636 3.7.45 10.881c-.6.605-.6 1.584 0 2.189l10.48 10.477c.604.604 1.582.604 2.186 0l10.43-10.43c.605-.603.605-1.582 0-2.187",
                    "Color":  "#F05032"
                },
    "GitHub.GitHubDesktop":  {
                                 "Path":  "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12",
                                 "Color":  "#6E40C9"
                             },
    "RARLab.WinRAR":  {
                          "Path":  "M2 2h20v6H2zM2 9h20v6H2zM2 16h20v6H2zM10 3v3h4V3zM10 10v3h4v-3zM10 17v3h4v-3z",
                          "Color":  "#8055A8"
                      },
    "9NKSQGP7F2NH":  {
                         "Path":  "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z",
                         "Color":  "#168C48"
                     },
    "EpicGames.EpicGamesLauncher":  {
                                        "Path":  "M3.537 0C2.165 0 1.66.506 1.66 1.879V18.44a4.262 4.262 0 00.02.433c.031.3.037.59.316.92.027.033.311.245.311.245.153.075.258.13.43.2l8.335 3.491c.433.199.614.276.928.27h.002c.314.006.495-.071.928-.27l8.335-3.492c.172-.07.277-.124.43-.2 0 0 .284-.211.311-.243.28-.33.285-.621.316-.92a4.261 4.261 0 00.02-.434V1.879c0-1.373-.506-1.88-1.878-1.88zm13.366 3.11h.68c1.138 0 1.688.553 1.688 1.696v1.88h-1.374v-1.8c0-.369-.17-.54-.523-.54h-.235c-.367 0-.537.17-.537.539v5.81c0 .369.17.54.537.54h.262c.353 0 .523-.171.523-.54V8.619h1.373v2.143c0 1.144-.562 1.71-1.7 1.71h-.694c-1.138 0-1.7-.566-1.7-1.71V4.82c0-1.144.562-1.709 1.7-1.709zm-12.186.08h3.114v1.274H6.117v2.603h1.648v1.275H6.117v2.774h1.74v1.275h-3.14zm3.816 0h2.198c1.138 0 1.7.564 1.7 1.708v2.445c0 1.144-.562 1.71-1.7 1.71h-.799v3.338h-1.4zm4.53 0h1.4v9.201h-1.4zm-3.13 1.235v3.392h.575c.354 0 .523-.171.523-.54V4.965c0-.368-.17-.54-.523-.54zm-3.74 10.147a1.708 1.708 0 01.591.108 1.745 1.745 0 01.49.299l-.452.546a1.247 1.247 0 00-.308-.195.91.91 0 00-.363-.068.658.658 0 00-.28.06.703.703 0 00-.224.163.783.783 0 00-.151.243.799.799 0 00-.056.299v.008a.852.852 0 00.056.31.7.7 0 00.157.245.736.736 0 00.238.16.774.774 0 00.303.058.79.79 0 00.445-.116v-.339h-.548v-.565H7.37v1.255a2.019 2.019 0 01-.524.307 1.789 1.789 0 01-.683.123 1.642 1.642 0 01-.602-.107 1.46 1.46 0 01-.478-.3 1.371 1.371 0 01-.318-.455 1.438 1.438 0 01-.115-.58v-.008a1.426 1.426 0 01.113-.57 1.449 1.449 0 01.312-.46 1.418 1.418 0 01.474-.309 1.58 1.58 0 01.598-.111 1.708 1.708 0 01.045 0zm11.963.008a2.006 2.006 0 01.612.094 1.61 1.61 0 01.507.277l-.386.546a1.562 1.562 0 00-.39-.205 1.178 1.178 0 00-.388-.07.347.347 0 00-.208.052.154.154 0 00-.07.127v.008a.158.158 0 00.022.084.198.198 0 00.076.066.831.831 0 00.147.06c.062.02.14.04.236.061a3.389 3.389 0 01.43.122 1.292 1.292 0 01.328.17.678.678 0 01.207.24.739.739 0 01.071.337v.008a.865.865 0 01-.081.382.82.82 0 01-.229.285 1.032 1.032 0 01-.353.18 1.606 1.606 0 01-.46.061 2.16 2.16 0 01-.71-.116 1.718 1.718 0 01-.593-.346l.43-.514c.277.223.578.335.9.335a.457.457 0 00.236-.05.157.157 0 00.082-.142v-.008a.15.15 0 00-.02-.077.204.204 0 00-.073-.066.753.753 0 00-.143-.062 2.45 2.45 0 00-.233-.062 5.036 5.036 0 01-.413-.113 1.26 1.26 0 01-.331-.16.72.72 0 01-.222-.243.73.73 0 01-.082-.36v-.008a.863.863 0 01.074-.359.794.794 0 01.214-.283 1.007 1.007 0 01.34-.185 1.423 1.423 0 01.448-.066 2.006 2.006 0 01.025 0zm-9.358.025h.742l1.183 2.81h-.825l-.203-.499H8.623l-.198.498h-.81zm2.197.02h.814l.663 1.08.663-1.08h.814v2.79h-.766v-1.602l-.711 1.091h-.016l-.707-1.083v1.593h-.754zm3.469 0h2.235v.658h-1.473v.422h1.334v.61h-1.334v.442h1.493v.658h-2.255zm-5.3.897l-.315.793h.624zm-1.145 5.19h8.014l-4.09 1.348z",
                                        "Color":  "#263238"
                                    },
    "Python.Python.3.14":  {
                               "Path":  "M14.25.18l.9.2.73.26.59.3.45.32.34.34.25.34.16.33.1.3.04.26.02.2-.01.13V8.5l-.05.63-.13.55-.21.46-.26.38-.3.31-.33.25-.35.19-.35.14-.33.1-.3.07-.26.04-.21.02H8.77l-.69.05-.59.14-.5.22-.41.27-.33.32-.27.35-.2.36-.15.37-.1.35-.07.32-.04.27-.02.21v3.06H3.17l-.21-.03-.28-.07-.32-.12-.35-.18-.36-.26-.36-.36-.35-.46-.32-.59-.28-.73-.21-.88-.14-1.05-.05-1.23.06-1.22.16-1.04.24-.87.32-.71.36-.57.4-.44.42-.33.42-.24.4-.16.36-.1.32-.05.24-.01h.16l.06.01h8.16v-.83H6.18l-.01-2.75-.02-.37.05-.34.11-.31.17-.28.25-.26.31-.23.38-.2.44-.18.51-.15.58-.12.64-.1.71-.06.77-.04.84-.02 1.27.05zm-6.3 1.98l-.23.33-.08.41.08.41.23.34.33.22.41.09.41-.09.33-.22.23-.34.08-.41-.08-.41-.23-.33-.33-.22-.41-.09-.41.09zm13.09 3.95l.28.06.32.12.35.18.36.27.36.35.35.47.32.59.28.73.21.88.14 1.04.05 1.23-.06 1.23-.16 1.04-.24.86-.32.71-.36.57-.4.45-.42.33-.42.24-.4.16-.36.09-.32.05-.24.02-.16-.01h-8.22v.82h5.84l.01 2.76.02.36-.05.34-.11.31-.17.29-.25.25-.31.24-.38.2-.44.17-.51.15-.58.13-.64.09-.71.07-.77.04-.84.01-1.27-.04-1.07-.14-.9-.2-.73-.25-.59-.3-.45-.33-.34-.34-.25-.34-.16-.33-.1-.3-.04-.25-.02-.2.01-.13v-5.34l.05-.64.13-.54.21-.46.26-.38.3-.32.33-.24.35-.2.35-.14.33-.1.3-.06.26-.04.21-.02.13-.01h5.84l.69-.05.59-.14.5-.21.41-.28.33-.32.27-.35.2-.36.15-.36.1-.35.07-.32.04-.28.02-.21V6.07h2.09l.14.01zm-6.47 14.25l-.23.33-.08.41.08.41.23.33.33.23.41.08.41-.08.33-.23.23-.33.08-.41-.08-.41-.23-.33-.33-.23-.41-.08-.41.08z",
                               "Color":  "#3776AB"
                           },
    "9NT1R1C2HH7J":  {
                         "Path":  "M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z",
                         "Color":  "#168A71"
                     },
    "Anthropic.Claude":  {
                             "Path":  "M17.3041 3.541h-3.6718l6.696 16.918H24Zm-10.6082 0L0 20.459h3.7442l1.3693-3.5527h7.0052l1.3693 3.5528h3.7442L10.5363 3.5409Zm-.3712 10.2232 2.2914-5.9456 2.2914 5.9456Z",
                             "Color":  "#B76E50"
                         },
    "RamenSoftware.Windhawk":  {
                                   "Path":  "M10 1h4l1 4 3-2 3 3-2 3 4 1v4l-4 1 2 3-3 3-3-2-1 4h-4l-1-4-3 2-3-3 2-3-4-1v-4l4-1-2-3 3-3 3 2zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
                                   "Color":  "#317BB5"
                               },
    "NVIDIA.App.Official":  {
                                "Path":  "M8.948 8.798v-1.43a6.7 6.7 0 0 1 .424-.018c3.922-.124 6.493 3.374 6.493 3.374s-2.774 3.851-5.75 3.851c-.398 0-.787-.062-1.158-.185v-4.346c1.528.185 1.837.857 2.747 2.385l2.04-1.714s-1.492-1.952-4-1.952a6.016 6.016 0 0 0-.796.035m0-4.735v2.138l.424-.027c5.45-.185 9.01 4.47 9.01 4.47s-4.08 4.964-8.33 4.964c-.37 0-.733-.035-1.095-.097v1.325c.3.035.61.062.91.062 3.957 0 6.82-2.023 9.593-4.408.459.371 2.34 1.263 2.73 1.652-2.633 2.208-8.772 3.984-12.253 3.984-.335 0-.653-.018-.971-.053v1.864H24V4.063zm0 10.326v1.131c-3.657-.654-4.673-4.46-4.673-4.46s1.758-1.944 4.673-2.262v1.237H8.94c-1.528-.186-2.73 1.245-2.73 1.245s.68 2.412 2.739 3.11M2.456 10.9s2.164-3.197 6.5-3.533V6.201C4.153 6.59 0 10.653 0 10.653s2.35 6.802 8.948 7.42v-1.237c-4.84-.6-6.492-5.936-6.492-5.936z",
                                "Color":  "#5A8F00"
                            },
    "Intel.IntelDriverAndSupportAssistant":  {
                                                 "Path":  "M20.42 7.345v9.18h1.651v-9.18zM0 7.475v1.737h1.737V7.474zm9.78.352v6.053c0 .513.044.945.13 1.292.087.34.235.618.44.828.203.21.475.359.803.451.334.093.754.136 1.255.136h.216v-1.533c-.24 0-.445-.012-.593-.037a.672.672 0 0 1-.39-.173.693.693 0 0 1-.173-.377 4.002 4.002 0 0 1-.037-.606v-2.182h1.193v-1.416h-1.193V7.827zm-3.505 2.312c-.396 0-.76.08-1.082.241-.327.161-.6.384-.822.668l-.087.117v-.902H2.658v6.256h1.639v-3.214c.018-.588.16-1.02.433-1.299.29-.297.642-.445 1.044-.445.476 0 .841.149 1.082.433.235.284.359.686.359 1.2v3.324h1.663V12.97c.006-.89-.229-1.595-.686-2.09-.458-.495-1.1-.742-1.917-.742zm10.065.006a3.252 3.252 0 0 0-2.306.946c-.29.29-.525.637-.692 1.033a3.145 3.145 0 0 0-.254 1.273c0 .452.08.878.241 1.274.161.395.39.742.674 1.032.284.29.637.526 1.045.693.408.173.86.26 1.342.26 1.397 0 2.262-.637 2.782-1.23l-1.187-.904c-.248.297-.841.699-1.583.699-.464 0-.847-.105-1.138-.321a1.588 1.588 0 0 1-.593-.872l-.019-.056h4.915v-.587c0-.451-.08-.872-.235-1.267a3.393 3.393 0 0 0-.661-1.033 3.013 3.013 0 0 0-1.02-.692 3.345 3.345 0 0 0-1.311-.248zm-16.297.118v6.256h1.651v-6.256zm16.278 1.286c1.132 0 1.664.797 1.664 1.255l-3.32.006c0-.458.525-1.255 1.656-1.261zm7.073 3.814a.606.606 0 0 0-.606.606.606.606 0 0 0 .606.606.606.606 0 0 0 .606-.606.606.606 0 0 0-.606-.606zm-.008.105a.5.5 0 0 1 .002 0 .5.5 0 0 1 .5.501.5.5 0 0 1-.5.5.5.5 0 0 1-.5-.5.5.5 0 0 1 .498-.5zm-.233.155v.699h.13v-.285h.093l.173.285h.136l-.18-.297a.191.191 0 0 0 .118-.056c.03-.03.05-.074.05-.136 0-.068-.02-.117-.063-.154-.037-.038-.105-.056-.185-.056zm.13.099h.154c.019 0 .037.006.056.012a.064.064 0 0 1 .037.031c.013.013.012.031.012.056a.124.124 0 0 1-.012.055.164.164 0 0 1-.037.031c-.019.006-.037.013-.056.013h-.154Z",
                                                 "Color":  "#0071C5"
                                             },
    "OpenJS.NodeJS.LTS":  {
                              "Path":  "M11.998,24c-0.321,0-0.641-0.084-0.922-0.247l-2.936-1.737c-0.438-0.245-0.224-0.332-0.08-0.383 c0.585-0.203,0.703-0.25,1.328-0.604c0.065-0.037,0.151-0.023,0.218,0.017l2.256,1.339c0.082,0.045,0.197,0.045,0.272,0l8.795-5.076 c0.082-0.047,0.134-0.141,0.134-0.238V6.921c0-0.099-0.053-0.192-0.137-0.242l-8.791-5.072c-0.081-0.047-0.189-0.047-0.271,0 L3.075,6.68C2.99,6.729,2.936,6.825,2.936,6.921v10.15c0,0.097,0.054,0.189,0.139,0.235l2.409,1.392 c1.307,0.654,2.108-0.116,2.108-0.89V7.787c0-0.142,0.114-0.253,0.256-0.253h1.115c0.139,0,0.255,0.112,0.255,0.253v10.021 c0,1.745-0.95,2.745-2.604,2.745c-0.508,0-0.909,0-2.026-0.551L2.28,18.675c-0.57-0.329-0.922-0.945-0.922-1.604V6.921 c0-0.659,0.353-1.275,0.922-1.603l8.795-5.082c0.557-0.315,1.296-0.315,1.848,0l8.794,5.082c0.57,0.329,0.924,0.944,0.924,1.603 v10.15c0,0.659-0.354,1.273-0.924,1.604l-8.794,5.078C12.643,23.916,12.324,24,11.998,24z M19.099,13.993 c0-1.9-1.284-2.406-3.987-2.763c-2.731-0.361-3.009-0.548-3.009-1.187c0-0.528,0.235-1.233,2.258-1.233 c1.807,0,2.473,0.389,2.747,1.607c0.024,0.115,0.129,0.199,0.247,0.199h1.141c0.071,0,0.138-0.031,0.186-0.081 c0.048-0.054,0.074-0.123,0.067-0.196c-0.177-2.098-1.571-3.076-4.388-3.076c-2.508,0-4.004,1.058-4.004,2.833 c0,1.925,1.488,2.457,3.895,2.695c2.88,0.282,3.103,0.703,3.103,1.269c0,0.983-0.789,1.402-2.642,1.402 c-2.327,0-2.839-0.584-3.011-1.742c-0.02-0.124-0.126-0.215-0.253-0.215h-1.137c-0.141,0-0.254,0.112-0.254,0.253 c0,1.482,0.806,3.248,4.655,3.248C17.501,17.007,19.099,15.91,19.099,13.993z",
                              "Color":  "#43853D"
                          },
    "Microsoft.DotNet.SDK.10":  {
                                    "Path":  "M24 8.77h-2.468v7.565h-1.425V8.77h-2.462V7.53H24zm-6.852 7.565h-4.821V7.53h4.63v1.24h-3.205v2.494h2.953v1.234h-2.953v2.604h3.396zm-6.708 0H8.882L4.78 9.863a2.896 2.896 0 0 1-.258-.51h-.036c.032.189.048.592.048 1.21v5.772H3.157V7.53h1.659l3.965 6.32c.167.261.275.442.323.54h.024c-.04-.233-.06-.629-.06-1.185V7.529h1.372zm-8.703-.693a.868.829 0 0 1-.869.829.868.829 0 0 1-.868-.83.868.829 0 0 1 .868-.828.868.829 0 0 1 .869.829Z",
                                    "Color":  "#512BD4"
                                },
    "EclipseAdoptium.Temurin.21.JDK":  {
                                           "Path":  "M11.915 0 11.7.215C9.515 2.4 7.47 6.39 6.046 10.483c-1.064 1.024-3.633 2.81-3.711 3.551-.093.87 1.746 2.611 1.55 3.235-.198.625-1.304 1.408-1.014 1.939.1.188.823.011 1.277-.491a13.389 13.389 0 0 0-.017 2.14c.076.906.27 1.668.643 2.232.372.563.956.911 1.667.911.397 0 .727-.114 1.024-.264.298-.149.571-.33.91-.5.68-.34 1.634-.666 3.53-.604 1.903.062 2.872.39 3.559.704.687.314 1.15.664 1.925.664.767 0 1.395-.336 1.807-.9.412-.563.631-1.33.72-2.24.06-.623.055-1.32 0-2.066.454.45 1.117.604 1.213.424.29-.53-.816-1.314-1.013-1.937-.198-.624 1.642-2.366 1.549-3.236-.08-.748-2.707-2.568-3.748-3.586C16.428 6.374 14.308 2.394 12.13.215zm.175 6.038a2.95 2.95 0 0 1 2.943 2.942 2.95 2.95 0 0 1-2.943 2.943A2.95 2.95 0 0 1 9.148 8.98a2.95 2.95 0 0 1 2.942-2.942zM8.685 7.983a3.515 3.515 0 0 0-.145.997c0 1.951 1.6 3.55 3.55 3.55 1.95 0 3.55-1.598 3.55-3.55 0-.329-.046-.648-.132-.951.334.095.64.208.915.336a42.699 42.699 0 0 1 2.042 5.829c.678 2.545 1.01 4.92.846 6.607-.082.844-.29 1.51-.606 1.94-.315.431-.713.651-1.315.651-.593 0-.932-.27-1.673-.61-.741-.338-1.825-.694-3.792-.758-1.974-.064-3.073.293-3.821.669-.375.188-.659.373-.911.5s-.466.2-.752.2c-.53 0-.876-.209-1.16-.64-.285-.43-.474-1.101-.545-1.948-.141-1.693.176-4.069.823-6.614a43.155 43.155 0 0 1 1.934-5.783c.348-.167.749-.31 1.192-.425zm-3.382 4.362a.216.216 0 0 1 .13.031c-.166.56-.323 1.116-.463 1.665a33.849 33.849 0 0 0-.547 2.555 3.9 3.9 0 0 0-.2-.39c-.58-1.012-.914-1.642-1.16-2.08.315-.24 1.679-1.755 2.24-1.781zm13.394.01c.562.027 1.926 1.543 2.24 1.783-.246.438-.58 1.068-1.16 2.08a4.428 4.428 0 0 0-.163.309 32.354 32.354 0 0 0-.562-2.49 40.579 40.579 0 0 0-.482-1.652.216.216 0 0 1 .127-.03z",
                                           "Color":  "#B85B18"
                                       },
    "GoLang.Go":  {
                      "Path":  "M1.811 10.231c-.047 0-.058-.023-.035-.059l.246-.315c.023-.035.081-.058.128-.058h4.172c.046 0 .058.035.035.07l-.199.303c-.023.036-.082.07-.117.07zM.047 11.306c-.047 0-.059-.023-.035-.058l.245-.316c.023-.035.082-.058.129-.058h5.328c.047 0 .07.035.058.07l-.093.28c-.012.047-.058.07-.105.07zm2.828 1.075c-.047 0-.059-.035-.035-.07l.163-.292c.023-.035.07-.07.117-.07h2.337c.047 0 .07.035.07.082l-.023.28c0 .047-.047.082-.082.082zm12.129-2.36c-.736.187-1.239.327-1.963.514-.176.046-.187.058-.34-.117-.174-.199-.303-.327-.548-.444-.737-.362-1.45-.257-2.115.175-.795.514-1.204 1.274-1.192 2.22.011.935.654 1.706 1.577 1.835.795.105 1.46-.175 1.987-.77.105-.13.198-.27.315-.434H10.47c-.245 0-.304-.152-.222-.35.152-.362.432-.97.596-1.274a.315.315 0 01.292-.187h4.253c-.023.316-.023.631-.07.947a4.983 4.983 0 01-.958 2.29c-.841 1.11-1.94 1.8-3.33 1.986-1.145.152-2.209-.07-3.143-.77-.865-.655-1.356-1.52-1.484-2.595-.152-1.274.222-2.419.993-3.424.83-1.086 1.928-1.776 3.272-2.02 1.098-.2 2.15-.07 3.096.571.62.41 1.063.97 1.356 1.648.07.105.023.164-.117.2m3.868 6.461c-1.064-.024-2.034-.328-2.852-1.029a3.665 3.665 0 01-1.262-2.255c-.21-1.32.152-2.489.947-3.529.853-1.122 1.881-1.706 3.272-1.95 1.192-.21 2.314-.095 3.33.595.923.63 1.496 1.484 1.648 2.605.198 1.578-.257 2.863-1.344 3.962-.771.783-1.718 1.273-2.805 1.495-.315.06-.63.07-.934.106zm2.78-4.72c-.011-.153-.011-.27-.034-.387-.21-1.157-1.274-1.81-2.384-1.554-1.087.245-1.788.935-2.045 2.033-.21.912.234 1.835 1.075 2.21.643.28 1.285.244 1.905-.07.923-.48 1.425-1.228 1.484-2.233z",
                      "Color":  "#008DAE"
                  },
    "Rustlang.Rustup":  {
                            "Path":  "M23.8346 11.7033l-1.0073-.6236a13.7268 13.7268 0 00-.0283-.2936l.8656-.8069a.3483.3483 0 00-.1154-.578l-1.1066-.414a8.4958 8.4958 0 00-.087-.2856l.6904-.9587a.3462.3462 0 00-.2257-.5446l-1.1663-.1894a9.3574 9.3574 0 00-.1407-.2622l.49-1.0761a.3437.3437 0 00-.0274-.3361.3486.3486 0 00-.3006-.154l-1.1845.0416a6.7444 6.7444 0 00-.1873-.2268l.2723-1.153a.3472.3472 0 00-.417-.4172l-1.1532.2724a14.0183 14.0183 0 00-.2278-.1873l.0415-1.1845a.3442.3442 0 00-.49-.328l-1.076.491c-.0872-.0476-.1742-.0952-.2623-.1407l-.1903-1.1673A.3483.3483 0 0016.256.955l-.9597.6905a8.4867 8.4867 0 00-.2855-.086l-.414-1.1066a.3483.3483 0 00-.5781-.1154l-.8069.8666a9.2936 9.2936 0 00-.2936-.0284L12.2946.1683a.3462.3462 0 00-.5892 0l-.6236 1.0073a13.7383 13.7383 0 00-.2936.0284L9.9803.3374a.3462.3462 0 00-.578.1154l-.4141 1.1065c-.0962.0274-.1903.0567-.2855.086L7.744.955a.3483.3483 0 00-.5447.2258L7.009 2.348a9.3574 9.3574 0 00-.2622.1407l-1.0762-.491a.3462.3462 0 00-.49.328l.0416 1.1845a7.9826 7.9826 0 00-.2278.1873L3.8413 3.425a.3472.3472 0 00-.4171.4171l.2713 1.1531c-.0628.075-.1255.1509-.1863.2268l-1.1845-.0415a.3462.3462 0 00-.328.49l.491 1.0761a9.167 9.167 0 00-.1407.2622l-1.1662.1894a.3483.3483 0 00-.2258.5446l.6904.9587a13.303 13.303 0 00-.087.2855l-1.1065.414a.3483.3483 0 00-.1155.5781l.8656.807a9.2936 9.2936 0 00-.0283.2935l-1.0073.6236a.3442.3442 0 000 .5892l1.0073.6236c.008.0982.0182.1964.0283.2936l-.8656.8079a.3462.3462 0 00.1155.578l1.1065.4141c.0273.0962.0567.1914.087.2855l-.6904.9587a.3452.3452 0 00.2268.5447l1.1662.1893c.0456.088.0922.1751.1408.2622l-.491 1.0762a.3462.3462 0 00.328.49l1.1834-.0415c.0618.0769.1235.1528.1873.2277l-.2713 1.1541a.3462.3462 0 00.4171.4161l1.153-.2713c.075.0638.151.1255.2279.1863l-.0415 1.1845a.3442.3442 0 00.49.327l1.0761-.49c.087.0486.1741.0951.2622.1407l.1903 1.1662a.3483.3483 0 00.5447.2268l.9587-.6904a9.299 9.299 0 00.2855.087l.414 1.1066a.3452.3452 0 00.5781.1154l.8079-.8656c.0972.0111.1954.0203.2936.0294l.6236 1.0073a.3472.3472 0 00.5892 0l.6236-1.0073c.0982-.0091.1964-.0183.2936-.0294l.8069.8656a.3483.3483 0 00.578-.1154l.4141-1.1066a8.4626 8.4626 0 00.2855-.087l.9587.6904a.3452.3452 0 00.5447-.2268l.1903-1.1662c.088-.0456.1751-.0931.2622-.1407l1.0762.49a.3472.3472 0 00.49-.327l-.0415-1.1845a6.7267 6.7267 0 00.2267-.1863l1.1531.2713a.3472.3472 0 00.4171-.416l-.2713-1.1542c.0628-.0749.1255-.1508.1863-.2278l1.1845.0415a.3442.3442 0 00.328-.49l-.49-1.076c.0475-.0872.0951-.1742.1407-.2623l1.1662-.1893a.3483.3483 0 00.2258-.5447l-.6904-.9587.087-.2855 1.1066-.414a.3462.3462 0 00.1154-.5781l-.8656-.8079c.0101-.0972.0202-.1954.0283-.2936l1.0073-.6236a.3442.3442 0 000-.5892zm-6.7413 8.3551a.7138.7138 0 01.2986-1.396.714.714 0 11-.2997 1.396zm-.3422-2.3142a.649.649 0 00-.7715.5l-.3573 1.6685c-1.1035.501-2.3285.7795-3.6193.7795a8.7368 8.7368 0 01-3.6951-.814l-.3574-1.6684a.648.648 0 00-.7714-.499l-1.473.3158a8.7216 8.7216 0 01-.7613-.898h7.1676c.081 0 .1356-.0141.1356-.088v-2.536c0-.074-.0536-.0881-.1356-.0881h-2.0966v-1.6077h2.2677c.2065 0 1.1065.0587 1.394 1.2088.0901.3533.2875 1.5044.4232 1.8729.1346.413.6833 1.2381 1.2685 1.2381h3.5716a.7492.7492 0 00.1296-.0131 8.7874 8.7874 0 01-.8119.9526zM6.8369 20.024a.714.714 0 11-.2997-1.396.714.714 0 01.2997 1.396zM4.1177 8.9972a.7137.7137 0 11-1.304.5791.7137.7137 0 011.304-.579zm-.8352 1.9813l1.5347-.6824a.65.65 0 00.33-.8585l-.3158-.7147h1.2432v5.6025H3.5669a8.7753 8.7753 0 01-.2834-3.348zm6.7343-.5437V8.7836h2.9601c.153 0 1.0792.1772 1.0792.8697 0 .575-.7107.7815-1.2948.7815zm10.7574 1.4862c0 .2187-.008.4363-.0243.651h-.9c-.09 0-.1265.0586-.1265.1477v.413c0 .973-.5487 1.1846-1.0296 1.2382-.4576.0517-.9648-.1913-1.0275-.4717-.2704-1.5186-.7198-1.8436-1.4305-2.4034.8817-.5599 1.799-1.386 1.799-2.4915 0-1.1936-.819-1.9458-1.3769-2.3153-.7825-.5163-1.6491-.6195-1.883-.6195H5.4682a8.7651 8.7651 0 014.907-2.7699l1.0974 1.151a.648.648 0 00.9182.0213l1.227-1.1743a8.7753 8.7753 0 016.0044 4.2762l-.8403 1.8982a.652.652 0 00.33.8585l1.6178.7188c.0283.2875.0425.577.0425.8717zm-9.3006-9.5993a.7128.7128 0 11.984 1.0316.7137.7137 0 01-.984-1.0316zm8.3389 6.71a.7107.7107 0 01.9395-.3625.7137.7137 0 11-.9405.3635z",
                            "Color":  "#9B4D24"
                        },
    "Kitware.CMake":  {
                          "Path":  "M11.769.066L.067 23.206l12.76-10.843zM23.207 23.934L7.471 17.587 0 23.934zM24 23.736L12.298.463l1.719 19.24zM12.893 12.959l-5.025 4.298 5.62 2.248z",
                          "Color":  "#2879A8"
                      },
    "Postman.Postman":  {
                            "Path":  "M13.527.099C6.955-.744.942 3.9.099 10.473c-.843 6.572 3.8 12.584 10.373 13.428 6.573.843 12.587-3.801 13.428-10.374C24.744 6.955 20.101.943 13.527.099zm2.471 7.485a.855.855 0 0 0-.593.25l-4.453 4.453-.307-.307-.643-.643c4.389-4.376 5.18-4.418 5.996-3.753zm-4.863 4.861l4.44-4.44a.62.62 0 1 1 .847.903l-4.699 4.125-.588-.588zm.33.694l-1.1.238a.06.06 0 0 1-.067-.032.06.06 0 0 1 .01-.073l.645-.645.512.512zm-2.803-.459l1.172-1.172.879.878-1.979.426a.074.074 0 0 1-.085-.039.072.072 0 0 1 .013-.093zm-3.646 6.058a.076.076 0 0 1-.069-.083.077.077 0 0 1 .022-.046h.002l.946-.946 1.222 1.222-2.123-.147zm2.425-1.256a.228.228 0 0 0-.117.256l.203.865a.125.125 0 0 1-.211.117h-.003l-.934-.934-.294-.295 3.762-3.758 1.82-.393.874.874c-1.255 1.102-2.971 2.201-5.1 3.268zm5.279-3.428h-.002l-.839-.839 4.699-4.125a.952.952 0 0 0 .119-.127c-.148 1.345-2.029 3.245-3.977 5.091zm3.657-6.46l-.003-.002a1.822 1.822 0 0 1 2.459-2.684l-1.61 1.613a.119.119 0 0 0 0 .169l1.247 1.247a1.817 1.817 0 0 1-2.093-.343zm2.578 0a1.714 1.714 0 0 1-.271.218h-.001l-1.207-1.207 1.533-1.533c.661.72.637 1.832-.054 2.522zM18.855 6.05a.143.143 0 0 0-.053.157.416.416 0 0 1-.053.45.14.14 0 0 0 .023.197.141.141 0 0 0 .084.03.14.14 0 0 0 .106-.05.691.691 0 0 0 .087-.751.138.138 0 0 0-.194-.033z",
                            "Color":  "#D9562E"
                        },
    "Microsoft.WindowsTerminal":  {
                                      "Path":  "M8.165 6V3h7.665v3H8.165zm-.5-3H1c-.55 0-1 .45-1 1v2h7.665V3zM23 3h-6.67v3H24V4c0-.55-.45-1-1-1zM0 6.5h24V20c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V6.5zM11.5 18c0 .3.2.5.5.5h8c.3 0 .5-.2.5-.5v-1.5c0-.3-.2-.5-.5-.5h-8c-.3 0-.5.2-.5.5V18zm-5.2-4.55l-3.1 3.1c-.25.25-.25.6 0 .8l.9.9c.25.25.6.25.8 0l4.4-4.4a.52.52 0 0 0 0-.8l-4.4-4.4c-.2-.2-.6-.2-.8 0l-.9.9c-.25.2-.25.55 0 .8l3.1 3.1z",
                                      "Color":  "#344A53"
                                  },
    "Opera.OperaGX":  {
                          "Path":  "M12 1a11 11 0 1 0 0 22 11 11 0 0 0 0-22zm0 2a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM7 9h10l3 7h-4l-2-2h-4l-2 2H4zm0 2v1H6v1h1v1h1v-1h1v-1H8v-1zm8 1h2v2h-2z",
                          "Color":  "#E32955"
                      },
    "Zoom.Zoom":  {
                      "Path":  "M3 5h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm16 4 4-3v12l-4-3z",
                      "Color":  "#2764E7"
                  },
    "qBittorrent.qBittorrent":  {
                                    "Path":  "M10 2h4v9h5l-7 7-7-7h5zM2 17h3v3h14v-3h3v6H2z",
                                    "Color":  "#377DB5"
                                },
    "BlenderFoundation.Blender":  {
                                      "Path":  "M12 1 23 7v10l-11 6L1 17V7zm0 3L5 8l7 4 7-4zm-8 6v5l7 4v-5zm16 0-7 4v5l7-4z",
                                      "Color":  "#D97620"
                                  },
    "AntibodySoftware.WizTree":  {
                                     "Path":  "M2 2h20v20H2zm2 2v16h7V4zm9 0v6h7V4zm0 8v8h3v-8zm5 0v8h2v-8z",
                                     "Color":  "#548F31"
                                 },
    "Anysphere.Cursor":  {
                             "Path":  "M2 2 20 13l-8 1-4 8zm1 1 5 14 3-5 5-1zM15 17l3-2 5 7-3 2z",
                             "Color":  "#34404A"
                         }
}
'@
# END BUNDLED APP ICONS
function Get-AppIcon([string]$id) {
 $definition=$iconDefinitions.$id
 if(-not $definition){throw (TF 'Missing app icon: {0}' @($id))}
 $drawing=[Windows.Media.DrawingGroup]::new()
 $bounds=[Windows.Media.RectangleGeometry]::new([Windows.Rect]::new(0,0,24,24))
 $drawing.Children.Add([Windows.Media.GeometryDrawing]::new([Windows.Media.Brushes]::Transparent,$null,$bounds))
 $brush=[Windows.Media.BrushConverter]::new().ConvertFromString($definition.Color)
 $geometry=[Windows.Media.Geometry]::Parse($definition.Path)
 $drawing.Children.Add([Windows.Media.GeometryDrawing]::new($brush,$null,$geometry))
 $icon=[Windows.Media.DrawingImage]::new($drawing)
 $icon.Freeze()
 return $icon
}
function Save-Selection {
 # DrawingImage objects belong to the UI; persist only user choices and results.
 Save-Json @($rows | Select-Object Id,Selected,Status) $savedPath
}
$lockName=if($ValidateUi){'Local\WinProvisionAppPickerTests'}elseif($Configure){'Local\WinProvisionAppConfiguration'}else{'Local\WinProvisionAppPicker'}
$uiLock=[Threading.Mutex]::new($false,$lockName)
$uiLocked=$false
try { $uiLocked=$uiLock.WaitOne(0) } catch [Threading.AbandonedMutexException] { $uiLocked=$true }
if(-not $uiLocked){$uiLock.Dispose();exit}
$script:running=$false
$script:workerProcess=$null
$script:activeJob=$null
$dataDir=Join-Path $env:LOCALAPPDATA 'WinProvision\Apps'
$savedPath=Join-Path $dataDir 'selection.json'
$languagePath=Join-Path $dataDir 'language.json'
if(-not $Preview -and (Test-Path -LiteralPath $languagePath)){
 try{$storedLanguage=(Get-Content -LiteralPath $languagePath -Raw | ConvertFrom-Json).Language;if($storedLanguage -in @('pt-BR','en-US')){$UiLanguage=$storedLanguage}}catch{}
}
$saved=@()
$autoStart=$false
if(-not $Preview) {
 New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
 try { if(Test-Path -LiteralPath $savedPath){$saved=@(Get-Content -LiteralPath $savedPath -Raw | ConvertFrom-Json)} } catch { $saved=@() }
 if($initialPlan.Mode -eq 'BeforeBoot' -and -not (Test-Path -LiteralPath (Join-Path $dataDir 'autostart-attempted'))){
  $saved=@($initialPlan.Ids | ForEach-Object { [pscustomobject]@{Id=$_;Selected=$true;Status='Available'} })
  $autoStart=$true
 }
}
if($Configure){$request=Get-Content -LiteralPath $SelectionPath -Raw | ConvertFrom-Json;$saved=@($request.Ids | ForEach-Object { [pscustomobject]@{Id=$_;Selected=$true;Status='Available'} })}
$rows=New-Object 'System.Collections.ObjectModel.ObservableCollection[Object]'
foreach($app in $catalog) {
 $previous=$saved | Where-Object Id -eq $app.Id | Select-Object -First 1
 $rows.Add([pscustomobject]@{Id=$app.Id;Name=$app.Name;RawCategory=$app.Category;RawDescription=$app.Description;Category=(T $app.Category);Description=(T $app.Description);StatusLabel='';Icon=(Get-AppIcon $app.Id);Selected=([bool]$previous.Selected);Status=if($previous.Status -in @('Completed','Concluído')){'Completed'}elseif($previous.Status -in @('Failed','Deferred')){$previous.Status}else{'Available'};Compatibility=(T 'Windows 10 and 11 · current catalog version')})
}
$script:attemptedIds=@($rows | Where-Object Status -in @('Completed','Failed','Deferred') | Select-Object -ExpandProperty Id)
[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="{DynamicResource Picker001}" Width="1080" Height="800" MinWidth="800" MinHeight="640" WindowStartupLocation="CenterScreen" Background="#F3F6F5" FontFamily="Segoe UI" FontSize="14" Foreground="#172A34">
 <Window.Resources>
  <Style TargetType="Button"><Setter Property="Padding" Value="16,10"/><Setter Property="Margin" Value="0,0,8,0"/><Setter Property="Background" Value="White"/><Setter Property="BorderBrush" Value="#CCD8D3"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="7" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.45"/></Trigger><Trigger Property="IsMouseOver" Value="True"><Setter Property="Opacity" Value="0.8"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="TextBlock"><Setter Property="TextWrapping" Value="Wrap"/></Style>
 </Window.Resources>
 <Grid Margin="30,24">
  <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
  <DockPanel><StackPanel DockPanel.Dock="Right" Margin="18,0,0,0"><TextBlock Text="Idioma / Language" FontSize="12"/><ComboBox Name="LanguageChoice" Width="170" Margin="0,5,0,0" AutomationProperties.Name="Idioma / Language"><ComboBoxItem Content="Português (Brasil)" Tag="pt-BR"/><ComboBoxItem Content="English" Tag="en-US"/></ComboBox></StackPanel><StackPanel><TextBlock Text="{DynamicResource Picker002}" Foreground="#0B7467" FontWeight="Bold" FontSize="12"/><TextBlock Text="{DynamicResource Picker003}" FontSize="30" FontWeight="SemiBold" Margin="0,10,0,6"/><TextBlock Text="{DynamicResource Picker004}" Foreground="#607480"/></StackPanel></DockPanel>
  <Border Grid.Row="1" Background="#E4EFEB" Padding="14,10" CornerRadius="8" Margin="0,18,0,16"><DockPanel><Button Name="Store" Content="{DynamicResource Picker005}" DockPanel.Dock="Right"/><TextBlock Name="Environment" VerticalAlignment="Center" Text="{DynamicResource Picker006}"/></DockPanel></Border>
  <StackPanel Grid.Row="2" Margin="0,0,0,12"><TextBlock Text="{DynamicResource Picker007}" FontSize="12" Margin="0,0,0,5"/><TextBox Name="Search" Padding="12,9" ToolTip="{DynamicResource Picker008}" AutomationProperties.Name="{DynamicResource Picker009}"/>
   <ListBox Name="Category" Margin="0,12,0,0" BorderThickness="0" Background="Transparent" ScrollViewer.HorizontalScrollBarVisibility="Disabled" AutomationProperties.Name="{DynamicResource Picker010}">
    <ListBox.ItemsPanel><ItemsPanelTemplate><WrapPanel/></ItemsPanelTemplate></ListBox.ItemsPanel>
    <ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Margin" Value="0,0,6,6"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><Border Name="TabBorder" Padding="12,7" CornerRadius="7" BorderThickness="1" BorderBrush="#D5DFDC" Background="White"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsSelected" Value="True"><Setter TargetName="TabBorder" Property="Background" Value="#0B7467"/><Setter Property="Foreground" Value="White"/><Setter Property="FontWeight" Value="SemiBold"/></Trigger><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="TabBorder" Property="BorderBrush" Value="#0B7467"/></Trigger><Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="TabBorder" Property="BorderBrush" Value="#0B7467"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></ListBox.ItemContainerStyle>
   </ListBox>
  </StackPanel>
  <ListBox Name="Apps" Grid.Row="3" BorderThickness="0" Background="Transparent" ScrollViewer.HorizontalScrollBarVisibility="Disabled" HorizontalContentAlignment="Stretch" SelectionMode="Single">
   <ListBox.GroupStyle><GroupStyle><GroupStyle.HeaderTemplate><DataTemplate><Border Padding="2,14,2,8"><StackPanel Orientation="Horizontal"><TextBlock Text="{Binding Name}" FontSize="18" FontWeight="SemiBold" Foreground="#0B7467"/><TextBlock Text="{Binding ItemCount, StringFormat=' ({0})'}" FontSize="14" Foreground="#607480" VerticalAlignment="Center"/></StackPanel></Border></DataTemplate></GroupStyle.HeaderTemplate></GroupStyle></ListBox.GroupStyle>
   <ListBox.ItemContainerStyle><Style TargetType="ListBoxItem"><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,0,8"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/></Style></ListBox.ItemContainerStyle>
   <ListBox.ItemTemplate><DataTemplate><Border Background="White" BorderBrush="#DCE5E1" BorderThickness="1" CornerRadius="9" Padding="16,12"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="36"/><ColumnDefinition Width="62"/><ColumnDefinition Width="*"/><ColumnDefinition Width="125"/></Grid.ColumnDefinitions><CheckBox IsChecked="{Binding Selected,Mode=TwoWay,UpdateSourceTrigger=PropertyChanged}" VerticalAlignment="Center" AutomationProperties.Name="{Binding Name}"/><Border Grid.Column="1" Width="46" Height="46" CornerRadius="10" Background="#F1F5F3" HorizontalAlignment="Left" VerticalAlignment="Center"><Image Source="{Binding Icon}" Width="30" Height="30" Stretch="Uniform" RenderOptions.BitmapScalingMode="HighQuality" Focusable="False"/></Border><StackPanel Grid.Column="2"><TextBlock Text="{Binding Name}" FontSize="17" FontWeight="SemiBold"/><TextBlock Text="{Binding Description}" Foreground="#607480" Margin="0,3,8,3"/><TextBlock Text="{Binding Compatibility}" Foreground="#73847D" FontSize="11"/></StackPanel><StackPanel Grid.Column="3" VerticalAlignment="Center"><TextBlock Text="{Binding Category}" Foreground="#607480" FontSize="12" HorizontalAlignment="Right"/><TextBlock Text="{Binding StatusLabel}" Foreground="#0B7467" FontWeight="SemiBold" HorizontalAlignment="Right" Margin="0,5,0,0"/></StackPanel></Grid></Border></DataTemplate></ListBox.ItemTemplate>
  </ListBox>
  <StackPanel Grid.Row="4" Margin="0,14,0,12"><Border Name="Summary" Visibility="Collapsed" Background="White" CornerRadius="8" Padding="12" Margin="0,0,0,10"><StackPanel><DockPanel><Button Name="Retry" DockPanel.Dock="Right"/><TextBlock Name="SummaryTitle" FontWeight="SemiBold" VerticalAlignment="Center"/></DockPanel><ScrollViewer MaxHeight="110" VerticalScrollBarVisibility="Auto"><TextBlock Name="SummaryText" Margin="0,8,0,0"/></ScrollViewer></StackPanel></Border><TextBlock Name="Status" Text="{DynamicResource Picker011}" FontWeight="SemiBold"/><ProgressBar Name="Progress" Height="5" Margin="0,9,0,8" Foreground="#0B7467"/><TextBlock Name="InstallTerms" Text="{DynamicResource Picker012}" Foreground="#607480" FontSize="12"/></StackPanel>
  <DockPanel Grid.Row="5"><StackPanel Orientation="Horizontal" DockPanel.Dock="Right"><Button Name="Later" Content="{DynamicResource Picker013}"/><Button Name="Install" Content="{DynamicResource Picker014}" Background="#0B7467" Foreground="White" Margin="0"/></StackPanel><StackPanel Orientation="Horizontal"><Button Name="Logs" Content="{DynamicResource Picker015}"/><Button Name="Stop" Content="{DynamicResource Picker016}" Visibility="Collapsed"/></StackPanel></DockPanel>
 </Grid>
</Window>
'@
$window=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($xaml))
foreach($name in @('Apps','Search','Category','Environment','Status','Progress','Install','Later','Logs','Stop','Store','InstallTerms','LanguageChoice','Summary','SummaryTitle','SummaryText','Retry')) { Set-Variable -Name $name -Value $window.FindName($name) }
function Get-FailedApps { @($rows | Where-Object { $_.Id -in $script:attemptedIds -and $_.Status -eq 'Failed' }) }
function Update-Summary {
 if(-not $script:attemptedIds -or $script:running){$Summary.Visibility='Collapsed';return}
 $SummaryTitle.Text=(T 'Installation summary')
 $lines=@(foreach($group in @('Completed','Failed','Deferred')){
  $items=@($rows | Where-Object { $_.Id -in $script:attemptedIds -and $_.Status -eq $group })
  (TF '{0} ({1}): {2}' @((T $group),$items.Count,($items.Name -join ', ')))
 })
 $SummaryText.Text=$lines -join "`n"
 $failed=@(Get-FailedApps).Count
 $Retry.Content=(TF 'Retry failures ({0})' @($failed))
 $Retry.IsEnabled=($failed -gt 0 -and -not $Preview)
 $Summary.Visibility='Visible'
}
$Apps.ItemsSource=$rows
$view=[Windows.Data.CollectionViewSource]::GetDefaultView($rows)
[void]$view.GroupDescriptions.Add([Windows.Data.PropertyGroupDescription]::new('Category'))
[void]$Category.Items.Add((T 'All apps'))
foreach($name in @($catalog.Category | Select-Object -Unique)){[void]$Category.Items.Add((T $name))}
$Category.SelectedIndex=0
$view.Filter={param($row) ($row.Name+' '+$row.Category+' '+$row.Description).IndexOf($Search.Text,[StringComparison]::OrdinalIgnoreCase) -ge 0 -and ($Category.SelectedIndex -eq 0 -or $row.Category -eq $Category.SelectedItem)}
$Search.Add_TextChanged({$view.Refresh()})
$Category.Add_SelectionChanged({$view.Refresh()})
if($Preview){$Environment.Text=(T 'INTERFACE PREVIEW · Installation is disabled. Nothing will be downloaded or installed.');$Store.IsEnabled=$false}
elseif(-not (Get-WingetPath)){$Environment.Text=(T 'App Installer is not available yet. Connect to the internet and update it in Microsoft Store.')}
if($autoStart){$InstallTerms.Text=(T 'These apps were selected and authorized in USB Builder. Installation starts automatically. Failures can be retried here.')}
if($Configure){$Environment.Text=(T 'CHOOSE NOW · Save the apps to install automatically on the new Windows. Nothing is installed on this PC.');$Later.Content=(T 'Cancel');$Logs.Visibility='Collapsed'}
function Update-PickerLanguage {
 $message=$Status.Text
 foreach($entry in $script:translationMap.GetEnumerator()){if($entry.Value -eq $message){$message=$entry.Key;break}}
 $Status.Text=(T $message)
 foreach($entry in $script:translationBundle.Resources.PSObject.Properties){$window.Resources[$entry.Name]=(T $entry.Value)}
 $categoryIndex=$Category.SelectedIndex
 $Category.Items.Clear()
 [void]$Category.Items.Add((T 'All apps'))
 foreach($name in @($catalog.Category | Select-Object -Unique)){[void]$Category.Items.Add((T $name))}
 $Category.SelectedIndex=[Math]::Max(0,$categoryIndex)
 foreach($row in $rows){$row.Category=(T $row.RawCategory);$row.Description=(T $row.RawDescription);$row.StatusLabel=(T $row.Status);$row.Compatibility=(T 'Windows 10 and 11 · current catalog version')}
 $view.Refresh()
 $Environment.Text=(T 'An internet connection is required. Windows may ask for permission to install.')
 if($Preview){$Environment.Text=(T 'INTERFACE PREVIEW · Installation is disabled. Nothing will be downloaded or installed.')}
 elseif(-not (Get-WingetPath)){$Environment.Text=(T 'App Installer is not available yet. Connect to the internet and update it in Microsoft Store.')}
 if($autoStart){$InstallTerms.Text=(T 'These apps were selected and authorized in USB Builder. Installation starts automatically. Failures can be retried here.')}
 if($Configure){$Environment.Text=(T 'CHOOSE NOW · Save the apps to install automatically on the new Windows. Nothing is installed on this PC.');$Later.Content=(T 'Cancel')}
 elseif($script:activeJob){$Later.Content=(T 'Finish')}
 $count=@($rows | Where-Object { $_.Selected -and $_.Status -ne 'Completed' }).Count
 $Install.Content=if($Configure){TF 'Save selection ({0})' @($count)}else{TF 'Install selected ({0})' @($count)}
 if(-not $script:activeJob){$Status.Text=(TF '{0} app(s) selected.' @($count))}
 Update-Summary
}
$LanguageChoice.SelectedIndex=if($UiLanguage -eq 'pt-BR'){0}else{1}
Update-PickerLanguage
$LanguageChoice.Add_SelectionChanged({
 if($script:running){return}
 $script:UiLanguage=[string]$LanguageChoice.SelectedItem.Tag
 Update-PickerLanguage
 if(-not $Preview){try{Save-Json @{Language=$script:UiLanguage} $languagePath}catch{}}
})
$Store.Add_Click({Start-Process 'ms-windows-store://pdp/?ProductId=9NBLGGH4NNS1'})
$Logs.Add_Click({if(-not $Preview){Start-Process explorer.exe -ArgumentList ('"'+$dataDir+'"')}})
$Later.Add_Click({$window.Close()})
$Stop.Add_Click({if($script:activeJob){[IO.File]::WriteAllText((Join-Path $script:activeJob 'stop'),'stop');$Stop.IsEnabled=$false;$Status.Text=(T 'Waiting for the current app to finish. Remaining apps will be deferred.')}})
function Start-AppQueue($selected,[switch]$RetryOnly) {
 try {
  if($Configure){Save-Json @{Ids=@($selected.Id);Saved=$true} $SelectionPath;$window.Close();return}
  if($Preview -or $selected.Count -eq 0 -or $script:running){return}
  Save-Selection
  $script:activeJob=Join-Path $dataDir ([guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $script:activeJob | Out-Null
  Save-Json @{Ids=@($selected.Id)} (Join-Path $script:activeJob 'request.json')
  $script:workerProcess=Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Worker -JobPath "'+$script:activeJob+'" -UiLanguage '+$script:UiLanguage) -WindowStyle Hidden -PassThru
  $script:running=$true
  if(-not $RetryOnly){$script:attemptedIds=@($selected.Id)}
  foreach($row in $selected){$row.Status='Queued';$row.StatusLabel=(T 'Queued')}
  $Summary.Visibility='Collapsed'
  if($autoStart){[IO.File]::WriteAllText((Join-Path $dataDir 'autostart-attempted'),'Automatic installation requested once. Use the interface to retry failures.')}
  $Apps.IsEnabled=$false;$Search.IsEnabled=$false;$Category.IsEnabled=$false;$LanguageChoice.IsEnabled=$false;$Install.IsEnabled=$false;$Later.IsEnabled=$false
  $Stop.Visibility='Visible';$Stop.IsEnabled=$true;$Progress.IsIndeterminate=$true
  $Status.Text=(T 'Preparing installation…')
 } catch { [Windows.MessageBox]::Show($_.Exception.Message,'WinProvision') | Out-Null }
}
$Install.Add_Click({Start-AppQueue @($rows | Where-Object { $_.Selected -and $_.Status -ne 'Completed' })})
$Retry.Add_Click({Start-AppQueue @(Get-FailedApps) -RetryOnly})
$timer=[Windows.Threading.DispatcherTimer]::new()
$timer.Interval=[TimeSpan]::FromMilliseconds(750)
$timer.Add_Tick({
 try {
  if(-not $script:running){
   $count=@($rows | Where-Object { $_.Selected -and $_.Status -ne 'Completed' }).Count
   $Install.IsEnabled=($Configure -or ($count -gt 0 -and -not $Preview))
   $Install.Content=if($Configure){(TF 'Save selection ({0})' @($count))}else{(TF 'Install selected ({0})' @($count))}
   if(-not $script:activeJob){$Status.Text=(TF '{0} app(s) selected.' @($count))}
   return
  }
  $statusFile=Join-Path $script:activeJob 'status.json'
  $state=$null
  if(Test-Path -LiteralPath $statusFile){try{$state=Get-Content -LiteralPath $statusFile -Raw | ConvertFrom-Json}catch{return}}
  if($state){
   foreach($item in $state.Items){$row=$rows | Where-Object Id -eq $item.Id; if($row){$row.Status=$item.Status;$row.StatusLabel=(T $row.Status)}}
   $view.Refresh()
   $Status.Text=$state.Message
   if($state.Items.Count -gt 0){$Progress.IsIndeterminate=$false;$Progress.Maximum=$state.Items.Count;$Progress.Value=@($state.Items | Where-Object { $_.Status -in @('Completed','Failed','Deferred') }).Count}
  }
  if($script:workerProcess.HasExited){
   if(-not $state -or -not $state.Done){$Status.Text=(T 'The installer was interrupted. Check the logs and try again.');foreach($row in $rows){if($row.Status -in @('Installing','Queued')){$row.Status='Failed';$row.StatusLabel=(T $row.Status)}}}
   foreach($row in $rows){if($row.Id -in $script:attemptedIds -and $row.Status -in @('Installing','Queued')){$row.Status='Failed';$row.StatusLabel=(T 'Failed')}}
   $script:running=$false;$Progress.IsIndeterminate=$false;$Apps.IsEnabled=$true;$Search.IsEnabled=$true;$Category.IsEnabled=$true;$LanguageChoice.IsEnabled=$true;$Later.IsEnabled=$true;$Later.Content=(T 'Finish');$Stop.Visibility='Collapsed'
   Save-Selection
   $view.Refresh()
   Update-Summary
  }
 } catch {$Status.Text=(T 'Unable to update progress: ')+$_.Exception.Message}
})
$window.Add_Closing({param($sender,$eventArgs)
 if($script:running){$eventArgs.Cancel=$true;$Status.Text=(T 'Wait for installation to finish or choose Stop after current app.');return}
 if(-not $Preview){try{Save-Selection}catch{}}
})
$window.Add_ContentRendered({
 if($autoStart -and -not $script:running -and -not $Preview){
  $Install.RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent))
 }
})
try {
 if($ValidateUi){
  if($rows.Count -ne 36 -or @($rows | Where-Object Selected).Count){throw 'Invalid initial catalog selection.'}
  if(@($rows | Where-Object { -not $_.Icon -or -not $_.Icon.IsFrozen -or $_.Icon.Width -le 0 }).Count){throw 'Bundled app icon failed to load.'}
  if($view.Groups.Count -ne 12 -or $Apps.GroupStyle.Count -ne 1){throw 'Visible category grouping failed.'}
  $Search.Text='firefox'; if(@($view).Count -ne 1 -or $view.Groups.Count -ne 1 -or $view.Groups[0].Name -ne (T 'Browsers')){throw 'Grouped search filter failed.'}
  $rows[0].Selected=$true
  $Search.Text='not-a-real-app'; if(@($view).Count -ne 0){throw 'Empty search failed.'}
  $Search.Text='';$Category.SelectedItem=(T 'Development');if(@($view).Count -ne 8){throw 'Category filter failed.'}
  $Category.SelectedIndex=0;if(@($view).Count -ne 36 -or $view.Groups.Count -ne 12 -or -not $rows[0].Selected){throw 'Selection preservation failed.'}
  foreach($language in @('pt-BR','en-US')){
   $LanguageChoice.SelectedIndex=if($language -eq 'pt-BR'){0}else{1}
   Update-PickerLanguage
   if($UiLanguage -ne $language -or -not $rows[0].Selected -or $rows[0].Status -ne 'Available'){throw 'Language switch lost selection or state.'}
   if($rows[0].Category -ne (T 'Browsers') -or $rows[0].StatusLabel -ne (T 'Available')){throw 'Category/status translation failed.'}
   if($window.Title -ne (T 'WinProvision · Your apps')){throw 'Window title translation failed.'}
   if($language -eq 'pt-BR'){
    foreach($app in $catalog){
     if((T $app.Description) -eq $app.Description){throw "Missing app description translation: $($app.Id)"}
     if($app.Category -ne 'Drivers' -and (T $app.Category) -eq $app.Category){throw "Missing app category translation: $($app.Id)"}
    }
   }
   $content=$window.Content;$content.Background=$window.Background
   $content.Measure([Windows.Size]::new(1000,760));$content.Arrange([Windows.Rect]::new(0,0,1000,760));$content.UpdateLayout()
   $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new(1000,760,96,96,[Windows.Media.PixelFormats]::Pbgra32);$bitmap.Render($content)
   $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
   $output=Join-Path $PSScriptRoot '..\artifacts\ui-validation'
   New-Item -ItemType Directory -Path $output -Force | Out-Null
   $file=[IO.File]::Create((Join-Path $output ("picker-"+$language+".png")))
   try{$encoder.Save($file)}finally{$file.Dispose()}
  }
  $script:attemptedIds=@($rows[0].Id,$rows[1].Id,$rows[2].Id)
  $rows[0].Status='Completed';$rows[1].Status='Failed';$rows[2].Status='Deferred';$rows[3].Status='Failed'
  $rows[1].Selected=$false;$rows[2].Selected=$true;$rows[3].Selected=$true
  $retryItems=@(Get-FailedApps)
  if($retryItems.Count -ne 1 -or $retryItems[0].Id -ne $rows[1].Id){throw 'Retry included completed, deferred, available or unrelated apps.'}
  foreach($language in @('pt-BR','en-US')){
   $LanguageChoice.SelectedIndex=if($language -eq 'pt-BR'){0}else{1}
   Update-PickerLanguage
   if($Summary.Visibility -ne 'Visible' -or $SummaryTitle.Text -ne (T 'Installation summary') -or $Retry.Content -ne (TF 'Retry failures ({0})' @(1))){throw 'Summary translation failed.'}
   foreach($index in 0..2){if(-not $SummaryText.Text.Contains($rows[$index].Name)){throw 'Summary omitted an attempted app.'}}
   $content.Measure([Windows.Size]::new(1000,760));$content.Arrange([Windows.Rect]::new(0,0,1000,760));$content.UpdateLayout()
   $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new(1000,760,96,96,[Windows.Media.PixelFormats]::Pbgra32);$bitmap.Render($content)
   $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
   $file=[IO.File]::Create((Join-Path $output ('picker-summary-'+$language+'.png')))
   try{$encoder.Save($file)}finally{$file.Dispose()}
  }
  $rows[1].Status='Completed';Update-Summary
  if(@(Get-FailedApps).Count -ne 0 -or $Retry.IsEnabled){throw 'Successful retry was not cleared.'}
  Write-Output 'PASS: WPF layout, bilingual summaries, retry-only selection, categories, search and selection persistence. No apps installed.'
 } else {$timer.Start();[void]$window.ShowDialog()}
} finally {$timer.Stop();if($uiLocked){$uiLock.ReleaseMutex()};$uiLock.Dispose()}
